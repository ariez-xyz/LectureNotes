//David Pape 01634454
public class OddNumbers extends ArithmeticSequence {
  public OddNumbers() {
    super(1, 2);
  }
}
