//David Pape 01634454
public class PrimeNumbers extends Sequence {

  public PrimeNumbers(int bound) {
    
  }

}
