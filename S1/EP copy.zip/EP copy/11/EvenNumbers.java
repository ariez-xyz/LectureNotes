//David Pape 01634454
public class EvenNumbers extends ArithmeticSequence {
  public EvenNumbers() {
    super(0, 2);
  }
}
