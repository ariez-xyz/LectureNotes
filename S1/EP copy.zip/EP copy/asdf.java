public class asdf{
public static void main(String[] args){
char x = 100;
System.out.println(x);
}}
