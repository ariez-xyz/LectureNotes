//David Pape 01634454
public class Parallelogram extends Shape {
    public boolean basicInside(double x0, double x1) {
        return -1 <= x0 && x0 <= 1 && -1 <= x1 && x1 <= 1;
    }
}
