//David Pape 01634454
public class NaturalNumbers extends ArithmeticSequence {
  public NaturalNumbers() {
    super(0, 1);
  }
}
