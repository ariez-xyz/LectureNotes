import java.util.Arrays;

//David Pape 01634454
//Johannes Spilka 11724817
//Filip Vecek 11700962
public class Sorter {
    static int maxNumber;

    public Sorter(int maxNumber) {
        this.maxNumber = maxNumber;
    }

    public static void countingsort(int[] a) {
        int[] counts = new int[maxNumber + 1];
        int[] result = new int[a.length];
        Arrays.fill(counts, 0);

        for (int i = 0; i < a.length; i++)
            counts[a[i]]++;

        for (int i = 1; i < maxNumber; i++)
            counts[i] += counts[i-1];

        for (int i = a.length - 1; i >= 0 ; i--) {
            result[counts[a[i]] - 1] = a[i];
            counts[a[i]]--;
        }
    }

    public static void insertionsort(int[] a) {
        for(int i = 1; i < a.length; i++) {
            int j = i - 1;
            int key = a[i];
            while(j >= 0 && a[j] > key) {
                a[j + 1] = a[j];
                j--;
            }
            a[j + 1] = key;
        }
    }

    public static void insertionsort(Integer[] a) {
        int[] b = new int[a.length];
        for(int i = 0; i < b.length; i++)
            b[i] = a[i];
        insertionsort(b);
        for(int i = 0; i < b.length; i++)
            a[i] = b[i];
    }

    public static void mergesort(Integer[] a) {
        int[] b = new int[a.length];
        for(int i = 0; i < b.length; i++)
            b[i] = a[i];
         mergesortRecursive(b, 0, a.length - 1);
        for(int i = 0; i < b.length; i++)
            a[i] = b[i];
    }

    public static void mergesortRecursive(int[] a, int p, int r) {
        if(p < r) {
            int q = (int) Math.floor(((double)p + r) / 2);
            mergesortRecursive(a, p, q);
            mergesortRecursive(a, q + 1, r);
            merge(a, p, q, r);
        }
    }

    public static void merge(int[] a, int p, int q, int r) {
        int n1 = q - p + 1;
        int n2 = r - q;
        int[] left = new int[n1 + 1];
        int[] right = new int[n2 + 1];

        for(int i = 0; i < n1; i++)
            left[i] = a[p + i];
        for(int j = 0; j < n2; j++)
            right[j] = a[q + j + 1];

        left[left.length - 1] = Integer.MAX_VALUE;
        right[right.length - 1] = Integer.MAX_VALUE;

        int i = 0;
        int j = 0;
        for(int k = p; k <= r; k++) {
            if(left[i] < right[j]) {
                a[k] = left[i];
                i++;
            } else {
                a[k] = right[j];
                j++;
            }
        }
    }
}
