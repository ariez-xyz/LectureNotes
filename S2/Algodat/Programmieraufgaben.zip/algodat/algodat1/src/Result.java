import java.text.DecimalFormat;
import java.text.NumberFormat;

//David Pape 01634454
//Johannes Spilka 11724817
//Filip Vecek 11700962
public class Result {
    int n;
    double mergesortTime;
    double insertionsortTime;
    double countingsortTime;

    public Result(int n, double mergesortTime, double insertionsortTime, double countingsortTime) {
        this.n = n;
        this.mergesortTime = Math.abs(mergesortTime) * 0.000000001;
        this.insertionsortTime = Math.abs(insertionsortTime) * 0.000000001;
        this.countingsortTime = Math.abs(countingsortTime) * 0.000000001;
    }

    @Override
    public String toString() {
        return "n:\t\t\t\t" + n +
                "\nMergesort:\t\t" + String.format("%.5g%n", mergesortTime) +
                "Insertionsort:\t" + String.format("%.5g%n", insertionsortTime) +
                "Countingsort:\t" + String.format("%.5g", countingsortTime);
    }

    public String toCSV() {
        NumberFormat formatter = new DecimalFormat("###.#####");
        return n + "," + formatter.format(mergesortTime)  + "," + formatter.format(insertionsortTime)  + "," + formatter.format(countingsortTime) + "\n";
    }

    public String toCollectiveCSV() {
        NumberFormat formatter = new DecimalFormat("###.#####");
        return "," + formatter.format(mergesortTime)  + "," + formatter.format(insertionsortTime)  + "," + formatter.format(countingsortTime);
    }
}
