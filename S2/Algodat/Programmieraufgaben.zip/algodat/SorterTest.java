import java.util.ArrayList;

//David Pape 01634454
//Johannes Spilka 11724817
//Filip Vecek 11700962
public class SorterTest {
    static int min = 100;
    static int max = 1000000;
    static double step = 10;
    static int maxNumber = 1000000;
    static ArrayList<ArrayList<Result>> results = new ArrayList<>();

    public static void main(String[] args) {
        Sorter s = new Sorter(maxNumber);
        for (int j = 0; j < 10; j++) {
            ArrayList<Result> result = new ArrayList<>();

            System.out.println("-----");
            System.out.println("Iteration " + j);
            System.out.println("-----\n");

            for (int len = min; len <= max; len = (int) (len * step)) {
                Integer[] a = new Integer[len];
                Integer[] b = new Integer[len];
                int[] c = new int[len];

                for (int i = 0; i < a.length; i++) {
                    a[i] = (int) Math.round(Math.random() * maxNumber);
                    b[i] = a[i];
                    c[i] = b[i];
                }

                long insertionSortTime = System.nanoTime();
                s.insertionsort(a);
                insertionSortTime = insertionSortTime - System.nanoTime();

                long mergeSortTime = System.nanoTime();
                s.mergesort(b);
                mergeSortTime = mergeSortTime - System.nanoTime();

                long countingSortTime = System.nanoTime();
                s.countingsort(c);
                countingSortTime = countingSortTime - System.nanoTime();

                Result r = new Result(len, mergeSortTime, insertionSortTime, countingSortTime);
                result.add(r);
                System.out.println(r + "\n");

                /*boolean sameResults = true;
                for(int i = 0; i < len; i++) {
                    if (!(a[i] == b[i] && b[i] == c[i])) {
                        sameResults = false;
                        break;
                    }
                }
                System.out.println("Equal results:\t" + sameResults + "\n");*/
            }

            results.add(result);
        }

        int n = min;
        System.out.println("CSV:");
        for (int i = 0; i < results.get(0).size(); i++) {
            n = (int)(n * step);
            System.out.print(n);
            for (ArrayList<Result> res : results)
                System.out.print(res.get(i).toCollectiveCSV());
            System.out.println();
        }
    }
}

