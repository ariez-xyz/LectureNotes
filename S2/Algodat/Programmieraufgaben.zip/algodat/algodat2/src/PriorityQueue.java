import java.util.Objects;

/**
 * Manages elements within a priority queue. All Elements in this queue must
 * implement the Comparable interface. If a element is requested from this data
 * structure the smallest one is returned. If there are multiple smallest
 * elements, one of them must be returned.
 */
public class PriorityQueue<T extends Comparable<T>> {

    public int heapSize = 0;
    public Object[] array;

    /**
     * Initialize an empty queue.
     */
    public PriorityQueue() {
        array = new Object[100];
    }

    /**
     * Add e to the queue.
     *
     * @param e The element which is be inserted (at the correct position) into the queue.
     */
    public void add(T e) {
        heapSize++;
        int i = heapSize - 1;

        array[heapSize - 1] = e;

        while(i > 0 && ((T) array[parent(i)]).compareTo((T) array[i]) > 0) {
            T a = (T) array[i];
            array[i] = array[parent(i)];
            array[parent(i)] = a;

            i = parent(i);
        }

   }

    /**
     * Returns and removes the smallest element in the queue.
     *
     * @return the smallest element
     */
    public T pop() {
        if(heapSize == 0)
            return null;

        heapSize--;
        T min = (T) array[0];
        array[0] = array[heapSize];
        array[heapSize] = null;

        minHeapify(0);

        return min;
    }

    /**
     * Return the current number of elements in the queue.
     *
     * @return the number of elements
     */
    public int size() {
        return heapSize;
    }

    public int parent(int index) {
        return (int) Math.floor(index / 2.0);
    }

    public int leftChild(int index) {
        return index * 2;
    }

    public int rightChild(int index) {
        return index * 2 + 1;
    }

    public void minHeapify(int index) {
        int l = leftChild(index);
        int r = rightChild(index);
        int smallest;

        if(l < heapSize && ((T) array[l]).compareTo((T) array[index]) < 0)
            smallest = l;
        else smallest = index;
        if(r < heapSize && ((T) array[r]).compareTo((T) array[smallest]) < 0)
            smallest = r;

        if(smallest != index) {
            Object a = array[index];
            array[index] = array[smallest];
            array[smallest] = a;

            minHeapify(smallest);
        }

    }
}
