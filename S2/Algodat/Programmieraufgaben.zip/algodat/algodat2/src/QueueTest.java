import java.util.Arrays;

public class QueueTest
{

    public static final int MAX_EL = 100;
    public static final int MAX_INT = 100;

    public static void main(String[] args)
    {
        PriorityQueue<Integer> queue = new PriorityQueue<>();

        for (int i = 0; i < MAX_EL; i++)
        {
            int rand = (int)(Math.random()*(MAX_INT+1));
            System.out.println("// ADD " + rand);
            queue.add(rand);
        }

        int last = Integer.MIN_VALUE;
        for (int i = 0; i < MAX_EL; i++)
        {
            int popd = queue.pop();
            System.out.println("// POP " + popd);

            if (last > popd)
                throw new RuntimeException(String.format("Last element was bigger than the current one: %d vs %d", last, popd));
            last = popd;
        }
    }
}
