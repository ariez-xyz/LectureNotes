import java.io.*;

public class GraphUtils {
    public static void main(String[] args) {
        try {
            String path = "./testgraph.txt";
            File file = new File(path);
            InputStream is = new FileInputStream(file);
            DirectedGraph graph = new DirectedGraph(is);

            File file1 = new File(path + "written.txt");
            OutputStream os = new FileOutputStream(file1);
            graph.print(os);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
