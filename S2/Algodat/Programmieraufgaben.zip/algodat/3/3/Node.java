import java.util.HashSet;
import java.util.Iterator;

public class Node implements Iterable<Edge> {
    HashSet<Edge> adjacencyList = new HashSet<>();
    String label;
    long id;

    public boolean addEdge(Edge e) {
        return adjacencyList.add(e);
    }

    public boolean removeEdge(Edge e) {
        return adjacencyList.remove(e);
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public Iterator<Edge> iterator() {
        return adjacencyList.iterator();
    }
}
