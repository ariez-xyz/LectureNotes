public class ParsingException extends Exception {

    public ParsingException() {
        super("Bad file format");
    }

    public ParsingException(String message, Throwable throwable) {
        super(message, throwable);
    }

}