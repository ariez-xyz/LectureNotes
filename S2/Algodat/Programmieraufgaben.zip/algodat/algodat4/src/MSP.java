//David Pape 01634454
public class MSP {
    DirectedGraph doPrim(DirectedGraph g) {
        
    }

    DirectedGraph doKruskal(DirectedGraph g) {

    }
}
