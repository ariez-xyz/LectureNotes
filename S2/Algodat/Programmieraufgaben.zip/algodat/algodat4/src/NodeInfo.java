//Johannes Spilka 11724817
//Filip Vecek 11700962
//David Pape 01634454

public class NodeInfo {
    int discovered;
    int finished;
    int distance;
    Node prev;
    String color;

    public NodeInfo(Node prev, String color) {
        this.prev = prev;
        this.color = color;
    }
}
