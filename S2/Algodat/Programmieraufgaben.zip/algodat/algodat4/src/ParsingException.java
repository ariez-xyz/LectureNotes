//Johannes Spilka 11724817
//Filip Vecek 11700962
//David Pape 01634454

public class ParsingException extends Exception {

    public ParsingException() {
        super("Bad file format");
    }

    public ParsingException(String message, Throwable throwable) {
        super(message, throwable);
    }

}