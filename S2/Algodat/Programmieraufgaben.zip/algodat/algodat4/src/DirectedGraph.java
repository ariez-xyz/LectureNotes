//Johannes Spilka 11724817
//Filip Vecek 11700962
//David Pape 01634454

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DirectedGraph implements Iterable<Node> {
    private HashMap<Integer, Node> nodes = new HashMap<>();
    private long currentId = 0;

    public DirectedGraph(InputStream is) throws IOException, ParsingException {
        ArrayList<String> lines = new ArrayList<>();
        int currentChar;
        String currentString = "";

        while((currentChar = is.read()) != -1) {
            currentString += (char) currentChar;

            if(currentChar == '\n') {
                lines.add(currentString);

                currentString = "";
            }
        }

        parse(lines);
    }

    private void parse(ArrayList<String> l) throws ParsingException {
        if(!Pattern.matches("digraph\\s\\{\\n", l.get(0)) || !Pattern.matches("}\\n", l.get(l.size() - 1)))
            throw new ParsingException();

        l.remove(0);
        l.remove(l.size() - 1);

        ArrayList<Pattern> patterns = new ArrayList<>();
        Pattern unlabeledNode = Pattern.compile("([0-9]+);\\n");
        Pattern labeledNode = Pattern.compile("([0-9]+)\\[label\\s=\\s\"(.+)\"\\];\\n");
        Pattern unweightedEdge = Pattern.compile("([0-9]+)\\s->\\s([0-9]+);\\n");
        Pattern weightedEdge = Pattern.compile("([0-9]+)\\s->\\s([0-9]+)\\[weight\\s=\\s([0-9]+(.[0-9]+)?)\\];\\n");
        Pattern whitespace = Pattern.compile("(\\s*\\t*)+\\n");



        for(String line : l) {

            if(unlabeledNode.matcher(line).matches()) {
                addNode(getIntGroup(unlabeledNode.matcher(line), 1),
                        null);

            } else if(labeledNode.matcher(line).matches()) {
                Matcher m = labeledNode.matcher(line);
                m.matches();
                addNode(Integer.parseInt(m.group(1)),
                        m.group(2));

            } else if(unweightedEdge.matcher(line).matches()) {
                addEdge(getIntGroup(unweightedEdge.matcher(line), 1),
                        getIntGroup(unweightedEdge.matcher(line), 2));

            } else if(weightedEdge.matcher(line).matches()) {
                addEdge(getIntGroup(weightedEdge.matcher(line), 1),
                        getIntGroup(weightedEdge.matcher(line), 2),
                        getFloatGroup(weightedEdge.matcher(line), 3));

            } else if(!whitespace.matcher(line).matches()) {
                throw new ParsingException();
            }
        }
    }

    private String test(Pattern p, String s) {
        if(p.matcher(s).matches())
            return s;
        return null;
    }

    //casts all chars in s to bytes one by one, then writes to os
    private void writeString(OutputStream os, String s) throws IOException {
        byte[] array = new byte[s.length()];
        char[] string = s.toCharArray();

        for (int i = 0; i < s.length(); i++)
            array[i] = (byte) string[i];

        os.write(array);
    }

    public void print(OutputStream os) throws IOException {
        writeString(os, "digraph {\n");

        StringBuilder builder = new StringBuilder();

        for(Node n : this) {
            String hasLabel = n.getId() == tryParsing(n.getLabel()) ? ";\n" : "[label = \"" + n.getLabel() + "\"];\n";

            writeString(os, "" + n.getId() + hasLabel);

            for(Edge e : n) {
                builder.append(n.getId() + " -> " + e.getNode().getId());

                String hasWeight = e.getWeight() > 1 ? "[weight = " + e.getWeight() + "];\n" : "\n";
                builder.append(hasWeight);
            }
        }

        writeString(os, "\n\n");
        writeString(os, builder.toString());
        writeString(os, "}");
    }

    public Long tryParsing(String s) {
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return -1L;
        }
    }

    private void addEdge(int from, int to) {
        addEdge(from, to, 1);
    }

    private void addEdge(int from, int to, float weight) {
        nodes.get(from).addEdge(new Edge(weight, nodes.get(to)));
    }

    private Node addNode(int id, String label) {
        Node n = new Node();

        n.setId(id);

        if(label == null)
            n.setLabel("" + id);
        else
            n.setLabel(label);

        return nodes.put(id, n);
    }

    private int getIntGroup(Matcher m, int group) {
        m.matches();
        return Integer.parseInt(m.group(group));
    }

    private float getFloatGroup(Matcher m, int group) {
        m.matches();
        return Float.parseFloat(m.group(group));
    }

    @Override
    public Iterator<Node> iterator() {
        return new Iterator<Node>() {
            int iteratorId = 0;

            @Override
            public boolean hasNext() {
                return iteratorId < nodes.size();
            }

            @Override
            public Node next() {
                do {
                    iteratorId++;
                } while (nodes.get(iteratorId) == null);

                return nodes.get(iteratorId);
            }
        };
    }

    public Node getNode(int id) {
        return nodes.get(id);
    }
}
