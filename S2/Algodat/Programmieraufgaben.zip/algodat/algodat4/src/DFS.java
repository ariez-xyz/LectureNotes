//Johannes Spilka 11724817
//Filip Vecek 11700962
//David Pape 01634454

import java.util.HashMap;

public class DFS {
    private int time;
    private DirectedGraph g;
    HashMap<Node, NodeInfo> infoMap = new HashMap<>();

    public void DFS(DirectedGraph dg) {
        g = dg;

        for(Node n : g) {
            infoMap.put(n, new NodeInfo(null, "WHITE"));
        }

        time = 0;

        for(Node n : g) {
            if(infoMap.get(n).color.equals("WHITE"))
                search(n);
        }
    }

    public void search(Node n) {
        infoMap.get(n).discovered = time++;
        infoMap.get(n).color = "GRAY";

        for(Edge e : n) {
            Node neighbor = e.getNode();

            if(infoMap.get(neighbor).color.equals("WHITE")) {
                infoMap.get(neighbor).prev = n;
                search(neighbor);
            }
        }

        infoMap.get(n).color = "BLACK";
        infoMap.get(n).discovered = time++;
    }
}
