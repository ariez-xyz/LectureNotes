//Johannes Spilka 11724817
//Filip Vecek 11700962
//David Pape 01634454

public class Edge {
    float weight;
    Node node;

    public Edge(float weight, Node node) {
        this.weight = weight;
        this.node = node;
    }

    public Edge(Node node) {
        this.node = node;
    }

    public float getWeight() {
        return weight;
    }

    public Node getNode() {
        return node;
    }

    public Node getNeighbour() {
        return getNode();
    }
}
