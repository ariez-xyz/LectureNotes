//Johannes Spilka 11724817
//Filip Vecek 11700962
//David Pape 01634454

import java.io.*;

public class GraphUtils {
    public static void main(String[] args) {
        try {
            String path = "./testgraph.txt";
            File file = new File(path);
            InputStream is = new FileInputStream(file);
            DirectedGraph graph = new DirectedGraph(is);

            File file1 = new File("testgraph_written.txt");
            OutputStream os = new FileOutputStream(file1);
            graph.print(os);

            DFS dfs = new DFS();
            dfs.DFS(graph);

            for(Node n : graph)
                System.out.println(dfs.infoMap.get(n).color);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
