/*************************************************** 
Interface Measurable: returns the specific measure of
	an object

UV Objektorientierte Programmierung / H.Hagenauer
***************************************************/

public interface Measurable {

	//returns the specific measure
	public double getMeasure ();  
}